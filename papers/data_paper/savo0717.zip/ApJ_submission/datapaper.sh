pdflatex datapaper
bibtex datapaper
pdflatex datapaper
pdflatex datapaper
##dvipdfm datapaper.dvi
